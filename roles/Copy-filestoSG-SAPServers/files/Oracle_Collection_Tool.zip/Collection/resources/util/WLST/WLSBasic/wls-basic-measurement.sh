#!/bin/sh
SCRIPT_VERSION="20.3($CT_BUILD_VERSION)"
SCRIPT_NAME=${0}
##########################################################################################
##   wls-basic-measurement     v 20.3
##    - Invoke WLS Basic feature usage script.  Connects to a running WLS server and 
##		returns WLS Basic feature usage information.
##
##  EXAMPLES
##    $ wls-basic-measurement
##


##############################################################
# make echo more portable
#

echo_Basic_printer() {
  #IFS=" " command 
  eval 'printf "%b\n" "$*"'
} 

##############################################################
# make echo more portable
#

echo_basic_log() {
	$ECHO_BASIC_PRINTER "$1" 
	$ECHO_BASIC_PRINTER "$1" >> $2
} 


# set up $ECHO
ECHO_BASIC_PRINTER="echo_Basic_printer"

################################################################################
#
# output welcome message.
#

beginMsg()
{
cat license_agreement.txt | more
ANSWER=

$ECHO_BASIC_PRINTER "Accept License Agreement? "
	while [ -z "${ANSWER}" ]
	do
		$ECHO_BASIC_PRINTER "$1 [y/n/q]: \c" >&2
  	read ANSWER
		#
		# Act according to the user's response.
		#
		case "${ANSWER}" in
			Y|y)
				return 0     # TRUE
				;;
			N|n|Q|q)
				exit 1     # FALSE
				;;
			#
			# An invalid choice was entered, reprompt.
			#
			*) ANSWER=
				;;
		esac
	done
}


################################################################################
#
#*********************************** MAIN **************************************
#
################################################################################

# command line defaults
SCRIPT_OPTIONS=


STANDALONE=
# check to see if Collection Tool is running, if not then print license. also skip ECHO setup
ps -eaf | grep Collection*.sh | grep -v grep >/dev/null 2>&1
if [ $? -eq 0 ] ; then
	STANDALONE="false"
else
	STANDALONE="true"
fi

if [ "${STANDALONE}" = "true" ] ; then
	
	# print welcome message
	beginMsg 
fi

if [ "${LICAGREE}" = "YES" ] ; then
	exit 1

fi
	
PYFILE=../resources/util/WLST/WLSBasic/wls-basic-measurement.py
COMPARE_RESULT_FILE=compare_result.txt
WLS_COLLECTED=$CT_TMP/logs/WLS_collected.log
WLS_WARNINGS=$CT_TMP/logs/WLS_warnings.log
WLS_ERRORS=$CT_TMP/logs/WLS_errors.log

QUIT_WLST=
if [ -f $COMPARE_RESULT_FILE ]
then
	QUIT_WLST=`cat $COMPARE_RESULT_FILE| grep QUIT_WLST | sed -e 's/QUIT_WLST=//g'`
fi

if [ -z "${MW_HOME}" ] ; then
	while [ -z "${MW_HOME}" -a -z "${QUIT_WLST}" ]
	do
		if [ -z "${MW_HOME}" ] ; then
			$ECHO_BASIC_PRINTER "Please enter the location that contains the wlserver or wlserver_10.3 directory as the MW_HOME."
			$ECHO_BASIC_PRINTER "For example: /app/Oracle/Middleware/ or similiar location"
			$ECHO_BASIC_PRINTER "To exit the running of the WebLogic Basic script, enter [quit or q]: \n"
			read MW_HOME
		fi
		
		WLST_SCRIPT_CURR=${MW_HOME}/oracle_common/common/bin/wlst.sh
		WLST_SCRIPT_OLD=${MW_HOME}/common/bin/wlst.sh
		
		if [ "${MW_HOME}" = "q" -o "${MW_HOME}" = "quit" -o "${MW_HOME}" = "Q" ]; then
			QUIT_WLST="yes"
			echo QUIT_WLST="yes" > $COMPARE_RESULT_FILE	
		elif [ -f "${WLST_SCRIPT_CURR}" ]; then
			WLSTFILE=$WLST_SCRIPT_CURR
		elif [ -f "${WLST_SCRIPT_OLD}" ]; then 
			WLSTFILE=$WLST_SCRIPT_OLD
		else
			$ECHO_BASIC_PRINTER "WebLogic WLST script, wlst.sh not found at $WLST_SCRIPT_CURR or $WLST_SCRIPT_OLD."
			$ECHO_BASIC_PRINTER "Please enter the $MW_HOME again.\n"	
			MW_HOME=
		fi
	done
	export MW_HOME
else
	WLST_SCRIPT_CURR=${MW_HOME}/oracle_common/common/bin/wlst.sh
	WLST_SCRIPT_OLD=${MW_HOME}/common/bin/wlst.sh

	if [ -f "${WLST_SCRIPT_CURR}" ]; then
		WLSTFILE=$WLST_SCRIPT_CURR
	elif [ -f "${WLST_SCRIPT_OLD}" ]; then 
		WLSTFILE=$WLST_SCRIPT_OLD
	else
		$ECHO_PRINTER "WebLogic WLST script, wlst.sh not found at $WLST_SCRIPT_CURR or $WLST_SCRIPT_OLD."
	fi
fi

if [ "${QUIT_WLST}" = "yes" ]; then
	rmdir $CT_TMP/WLSBasic 2>/dev/null
	echo_basic_log "CT: WLS-03001: WARNING: User chose to quit WL Basic measurement script." $WLS_WARNINGS
		
else
	if [ -f $MW_HOME/wlserver/server/bin/setWLSEnv.sh ]; then
		. "$MW_HOME/wlserver/server/bin/setWLSEnv.sh"
	elif [ -f $MW_HOME/wlserver_10.3/server/bin/setWLSEnv.sh ]; then
		. "$MW_HOME/wlserver_10.3/server/bin/setWLSEnv.sh"
	fi
	
	if [ ! -d $CT_TMP/WLSBasic ] ; then
		mkdir -p $CT_TMP/WLSBasic 
	fi	

	WLST_MACHINE_NAME=`uname -n`
	${WLSTFILE} ${PYFILE} ${WLST_MACHINE_NAME}

fi



