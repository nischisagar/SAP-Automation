# WLST Domain filtering script
# The script will use WLST Offline querying of mbeans to gather only the data
# needed for Oracle Fusion Middleware licensing purposes.
import sys, os
import java
import string

from java.io import File
from java.io import FileOutputStream
from java.lang import System
from java.text import DateFormat
from java.util import Iterator

import javax.management.ObjectName
import javax.management.Query
import javax.management.QueryExp
import weblogic.management.configuration

WLSDomainFilter_script_version = "20.3"

# get a listing of everything in the current directory
def findMBean(v_pattern):
	mydirs = ls(returnMap='true')
	v_compile_pattern = java.util.regex.Pattern.compile(v_pattern)
	
	found = 'no'

	for mydir in mydirs:
		x = java.lang.String(mydir)
		v_matched = v_compile_pattern.matcher(x)
		if v_matched.find():
			found = 'true'
			
		return found

# Get the list of servers and filter-in only information 
# that is useful for licensing purposes
def serverInfo():
	#get the list of servers
	cd('/')
	servers=cmo.getServers()
	if (servers != None):
		for server in servers:
			serverName = server.getName()
			
			cluster = server.getCluster()
				
			ListenAddress =  server.getListenAddress()
			ListenPort =  server.getListenPort()
			
			machine = server.getMachine()
			
			print "\t<server>"
			print "\t\t<name>" + serverName + "</name>"
			if (cluster != None):
				print "\t\t<cluster>" + cluster.getName() + "</cluster>"
			
			if ( machine != None):
				print "\t\t<machine>" + machine.getName() + "</machine>"
			
			#if ListenAddress:
			#	print "\t\t<listen-address>" + ListenAddress + "</listen-address>"
			
			#if ListenPort:
			#	print "\t\t<listen-port>" + str(ListenPort) + "</listen-port>"

			try:
				cd("/Server/"+serverName)
				hasOverloadProtection = findMBean("OverloadProtection")
				if ( hasOverloadProtection == 'true'):
					cd("OverloadProtection/NO_NAME_0")
					failureAction = cmo.getFailureAction()
					panicAction = cmo.getPanicAction()
					print "\t\t<overload-protection>"
					print "\t\t\t<failure-action>" + failureAction + "</failure-action>"
					print "\t\t\t<panic-action>" + panicAction + "</panic-action>"
					print "\t\t</overload-protection>"

			except Exception:
				sys.exc_clear()
	
			print "\t</server>"

# Get the list of clusters and filter-in only information 
# that is useful for licensing purposes
def clusterInfo():
	cd('/')
	clusters=cmo.getClusters()
	if (clusters != None):
		for cluster in clusters:
			clusterName = cluster.getName()
			
			ClusterMessagingMode = cluster.getClusterMessagingMode()
			ClusterAddress = cluster.getClusterAddress()
			MulticastAddress = cluster.getMulticastAddress()
			MulticastPort = cluster.getMulticastPort()
			print "\t<cluster>"
			print "\t\t<name>" + clusterName + "</name>" 
			if (ClusterAddress != None):
				print "\t\t<cluster-address>" + ClusterAddress + "<\cluster-address>"
		
			if (ClusterMessagingMode != None):
				print "\t\t<cluster-messaging-mode>" + ClusterMessagingMode	+  "</cluster-messaging-mode>"
		
		#	if (MulticastAddress != None):
		#		print "\t\t<multicast-address>"	+ MulticastAddress + "</multicast-address>"
		
		#	if (MulticastPort != None):
		#		print "\t\t<multicast-port>"	+ str(MulticastPort) + "</multicast-port>"
			try:
				cd("/Cluster/"+clusterName)
				hasOverloadProtection = findMBean("OverloadProtection")
				if ( hasOverloadProtection == 'true'):
					cd("OverloadProtection/NO_NAME_0")
					failureAction = cmo.getFailureAction()
					panicAction = cmo.getPanicAction()
					print "\t\t<overload-protection>"
					print "\t\t\t<failure-action>" + failureAction + "</failure-action>"
					print "\t\t\t<panic-action>" + panicAction + "</panic-action>"
					print "\t\t</overload-protection>"
			except Exception:
				sys.exc_clear()
					
			print "\t</cluster>"		

# Check for app deployments and	
# get all the deployed apps 
def attributeInfo():
	cd('/')
	applicationDeployments = cmo.getAppDeployments()

	if (applicationDeployments != None ):
		for applicationDeployment in applicationDeployments:
			applicationDeploymentName = applicationDeployment.getName()
			print "\t<app-deployment>"
			versionIdentifier = applicationDeployment.getVersionIdentifier()
			print "\t\t<name>" + applicationDeploymentName + str(versionIdentifier) + "</name>"
			
			moduleType = applicationDeployment.getModuleType()
			
			if moduleType:
				print "\t\t<module-type>" + moduleType + "</module-type>"
			
			targets = applicationDeployment.getTargets()
			tmpTarget = ''
			targetCount = 0
			if (targets != None):
				for target in targets:
					if (targetCount == 0 ):
						tmpTarget = target.getName()
						targetCount += 1
					else:
						tmpTarget += "," + target.getName()
				
				print "\t\t<target>" + str(tmpTarget) + "</target>"

			sourcePath = applicationDeployment.getSourcePath()
			deploymentOrder = applicationDeployment.getDeploymentOrder()
			if sourcePath:
				print "\t\t<source-path>" + sourcePath + "</source-path>"

			if 	deploymentOrder:
				print "\t\t<deployment-order>" + str(deploymentOrder) + "</deployment-order>"
			
			print "\t</app-deployment>"
	
# Get all the deployed libraries
def libraryInfo():
	cd('/')
	libraries = cmo.getLibraries()	
	
	if (libraries != None ):
		for library in libraries:
			libraryName = library.getName()
			libraryVersionIdentifier = library.getVersionIdentifier()
			print "\t<library>"	
			print "\t\t<name>" + libraryName + str(libraryVersionIdentifier) + "</name>"
			
			moduleType = library.getModuleType()			
			if moduleType:
				print "\t\t<module-type>" + moduleType + "</module-type>"
			
			targets = library.getTargets()
			tmpTarget = ''
			targetCount = 0
			if (targets != None):
				for target in targets:
					if (targetCount == 0 ):
						tmpTarget = target.getName()
						targetCount += 1
					else:
						tmpTarget += "," + target.getName()
				
				print "\t\t<target>" + str(tmpTarget) + "</target>"

			sourcePath = library.getSourcePath()
			deploymentOrder = library.getDeploymentOrder()		

			if sourcePath:
				print "\t\t<source-path>" + sourcePath + "</source-path>"
			
			if deploymentOrder:
				print "\t\t<deployment-order>" + str(deploymentOrder) + "</deployment-order>"				
	
			print "\t</library>"

		
# Test for JDBC info
def jdbcInfo():
	cd('/')
	jdbcSystemResources = cmo.getJDBCSystemResources()

	try:
		if (jdbcSystemResources != None):
			for jdbcSystemResource in jdbcSystemResources:
				jdbcResourceName = jdbcSystemResource.getName()
				cd("/JDBCSystemResources/" + jdbcResourceName + "/JdbcResource/"+ jdbcResourceName + "/JDBCDataSourceParams/NO_NAME_0" )

				dataSourceList = cmo.getDataSourceList()
				cd("/JDBCSystemResources/" + jdbcResourceName + "/JdbcResource/" + jdbcResourceName )
				##dataSourceType = cmo.getDatasourceType()
				
				print "\t<jdbc-system-resource>"
				print "\t\t<data-source-list>" + str(dataSourceList) + "</data-source-list>"
				##print "\t\t<data-source-type>" + str(dataSourceType) + "</data-source-type>"
				print "\t</jdbc-system-resource>"

	except Exception:
		sys.exc_clear()

# Test for diagnostics framework usage
def wldfInfo():
	cd('/')
	WLDFSystemResources = cmo.getWLDFSystemResources()
	if (WLDFSystemResources != None):
		for WLDFSystemResource in WLDFSystemResources:
			print "\t<wldf-system-resource>"
			name = WLDFSystemResource.getName()
			print "\t\t<name>" + name + "</name>"
			print "\t</wldf-system-resource>"

	
# Function End

# Main
domainHomesEnv = os.environ["CT_DOMAIN_HOMES"]
domainHomesList = domainHomesEnv.split(';')
prev = theInterpreter.getOut()
prevErr = theInterpreter.getErr()
if os.name == "nt":
	WLSDomainFilterError = File(os.environ["WINDOWSCMDERR"])
else:
	WLSDomainFilterError = File(os.environ["UNIXCMDERR"])

fosWLSDomainFilterError = FileOutputStream(WLSDomainFilterError)
theInterpreter.setErr(fosWLSDomainFilterError)

for domainHomes in domainHomesList:
	configFileLocation = domainHomes + os.sep + 'config' +os.sep +'config.xml'
	if os.path.exists(configFileLocation):
		try:
			tempDomainHome = os.environ["CT_TMP"] + os.sep + "FMW" +os.sep + domainHomes.replace(":","") + os.sep + 'config' + os.sep
			tempConfigFile = tempDomainHome + 'config.xml.tmp'
			
			if not os.path.exists(tempDomainHome):
				os.makedirs(tempDomainHome)
				
			# OPEN the output file and start to write to it
			DomainFilter_output = File(tempConfigFile)
			#print "Saving output to " + str(DomainFilter_output)

			fosDomainFilterOut = FileOutputStream(DomainFilter_output)
			theInterpreter.setOut(fosDomainFilterOut)

			# Read in the Domain Configuration
			readDomain(domainHomes)

			print "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
			print "<domain xsi:schemaLocation=\"http://xmlns.oracle.com/weblogic/domain  http://xmlns.oracle.com/weblogic/1.0/domain.xsd\" xmlns=\"http://xmlns.oracle.com/weblogic/domain\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
			print "<!-- Filtering with WLSDomainFilter version " + WLSDomainFilter_script_version + " -->"

			# From Top of Domain MBean Tree, obtain some high level domain attributes.
			DomainName = get('Name')
			DomainVersion = get('DomainVersion')
			print "\t<name>" + DomainName + "</name>"
			
			print "\t<domain-version>" + DomainVersion + "</domain-version>"
			print "\t<configuration-version>" + DomainVersion + "</configuration-version>"

			serverInfo()
			clusterInfo()
			attributeInfo()
			libraryInfo()
			jdbcInfo()
			wldfInfo()
			
			print " "

			print "</domain>"
			
			closeDomain()
			fosDomainFilterOut.close()
			os.rename(tempConfigFile, tempDomainHome + 'config.xml')
		
		except:
			fosDomainFilterOut.close()
			theInterpreter.setOut(fosWLSDomainFilterError)
			print "WLST could not filter " + configFileLocation + ". Filtering will be done with scripting."
			theInterpreter.setOut(prevErr)
			print "WLST could not filter " + configFileLocation + ". Filtering will be done with scripting."
			if os.path.exists(tempConfigFile):
				os.remove(tempConfigFile)




fosWLSDomainFilterError.close()	  
theInterpreter.setOut(prev)
theInterpreter.setErr(prevErr)
print 
print "End of WLSDomainFilter"
	
	
exit()
