#!/bin/sh
echo "testing execution privs" >"$1/check_privs.log"
